﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace NewInjectorV2
{
    public partial class Form1 : Form
    {
        readonly ExploitAPI api = new ExploitAPI();
        public Form1()
        {
            InitializeComponent();
            CheckInjected();
        }

        Point lastPoint;

        private void CloseButt_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MinimazedButt_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private async void InjectButt_Click(object sender, EventArgs e)
        {
            api.LaunchExploit();
            await Task.Delay(3000);
            CheckInjected();
            await Task.Delay(3000);
            CheckInjected();
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeadName_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeadName_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private async void CheckInjected()
        {
            if (api.isAPIAttached())
            {
                InjectButt.Text = "Injected";
                await Task.Delay(1000);
                this.Hide();
                Main main = new Main();
                main.Show();
            }
            else
            {
                InjectButt.Text = "Inject";
            }
        }

        private void InjectorChecker_Tick(object sender, EventArgs e)
        {
            CheckInjected();
        }
    }
}
