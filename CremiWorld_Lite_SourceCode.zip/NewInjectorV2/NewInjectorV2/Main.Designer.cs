﻿namespace NewInjectorV2
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.panel1 = new System.Windows.Forms.Panel();
            this.HeadText = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.CloseButt = new System.Windows.Forms.Button();
            this.fastColoredTextBox1 = new FastColoredTextBoxNS.FastColoredTextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.ExecuteButt = new System.Windows.Forms.Button();
            this.SaveFileButt = new System.Windows.Forms.Button();
            this.OpenFileButt = new System.Windows.Forms.Button();
            this.RefreshButt = new System.Windows.Forms.Button();
            this.InjectorChecker = new System.Windows.Forms.Timer(this.components);
            this.ClearButt = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.HeadText);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.CloseButt);
            this.panel1.Location = new System.Drawing.Point(-13, -16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1101, 84);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // HeadText
            // 
            this.HeadText.AutoSize = true;
            this.HeadText.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HeadText.ForeColor = System.Drawing.Color.White;
            this.HeadText.Location = new System.Drawing.Point(421, 19);
            this.HeadText.Name = "HeadText";
            this.HeadText.Size = new System.Drawing.Size(255, 45);
            this.HeadText.TabIndex = 1;
            this.HeadText.Text = "CremiWorld Lite";
            this.HeadText.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeadText_MouseDown);
            this.HeadText.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeadText_MouseMove);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(907, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 62);
            this.button1.TabIndex = 1;
            this.button1.Text = "_";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CloseButt
            // 
            this.CloseButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.CloseButt.FlatAppearance.BorderSize = 0;
            this.CloseButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButt.ForeColor = System.Drawing.Color.White;
            this.CloseButt.Location = new System.Drawing.Point(988, 19);
            this.CloseButt.Name = "CloseButt";
            this.CloseButt.Size = new System.Drawing.Size(75, 62);
            this.CloseButt.TabIndex = 0;
            this.CloseButt.Text = "X";
            this.CloseButt.UseVisualStyleBackColor = false;
            this.CloseButt.Click += new System.EventHandler(this.CloseButt_Click);
            // 
            // fastColoredTextBox1
            // 
            this.fastColoredTextBox1.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.fastColoredTextBox1.AutoIndentCharsPatterns = "\r\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>.+)\r\n";
            this.fastColoredTextBox1.AutoScrollMinSize = new System.Drawing.Size(411, 29);
            this.fastColoredTextBox1.BackBrush = null;
            this.fastColoredTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.fastColoredTextBox1.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.fastColoredTextBox1.CharHeight = 29;
            this.fastColoredTextBox1.CharWidth = 16;
            this.fastColoredTextBox1.CommentPrefix = "--";
            this.fastColoredTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fastColoredTextBox1.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.fastColoredTextBox1.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.fastColoredTextBox1.ForeColor = System.Drawing.Color.White;
            this.fastColoredTextBox1.IndentBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.fastColoredTextBox1.IsReplaceMode = false;
            this.fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Lua;
            this.fastColoredTextBox1.LeftBracket = '(';
            this.fastColoredTextBox1.LeftBracket2 = '{';
            this.fastColoredTextBox1.Location = new System.Drawing.Point(12, 74);
            this.fastColoredTextBox1.Name = "fastColoredTextBox1";
            this.fastColoredTextBox1.Paddings = new System.Windows.Forms.Padding(0);
            this.fastColoredTextBox1.RightBracket = ')';
            this.fastColoredTextBox1.RightBracket2 = '}';
            this.fastColoredTextBox1.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.fastColoredTextBox1.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("fastColoredTextBox1.ServiceColors")));
            this.fastColoredTextBox1.Size = new System.Drawing.Size(818, 377);
            this.fastColoredTextBox1.TabIndex = 1;
            this.fastColoredTextBox1.Text = "-- Write here your code";
            this.fastColoredTextBox1.Zoom = 100;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.ForeColor = System.Drawing.Color.White;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(836, 74);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(214, 375);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // ExecuteButt
            // 
            this.ExecuteButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ExecuteButt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ExecuteButt.FlatAppearance.BorderSize = 3;
            this.ExecuteButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExecuteButt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ExecuteButt.ForeColor = System.Drawing.Color.White;
            this.ExecuteButt.Location = new System.Drawing.Point(13, 458);
            this.ExecuteButt.Name = "ExecuteButt";
            this.ExecuteButt.Size = new System.Drawing.Size(194, 61);
            this.ExecuteButt.TabIndex = 3;
            this.ExecuteButt.Text = "Execute";
            this.ExecuteButt.UseVisualStyleBackColor = false;
            this.ExecuteButt.Click += new System.EventHandler(this.ExecuteButt_Click);
            // 
            // SaveFileButt
            // 
            this.SaveFileButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.SaveFileButt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.SaveFileButt.FlatAppearance.BorderSize = 3;
            this.SaveFileButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveFileButt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveFileButt.ForeColor = System.Drawing.Color.White;
            this.SaveFileButt.Location = new System.Drawing.Point(213, 457);
            this.SaveFileButt.Name = "SaveFileButt";
            this.SaveFileButt.Size = new System.Drawing.Size(194, 61);
            this.SaveFileButt.TabIndex = 4;
            this.SaveFileButt.Text = "SaveFile";
            this.SaveFileButt.UseVisualStyleBackColor = false;
            this.SaveFileButt.Click += new System.EventHandler(this.SaveFileButt_Click);
            // 
            // OpenFileButt
            // 
            this.OpenFileButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.OpenFileButt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.OpenFileButt.FlatAppearance.BorderSize = 3;
            this.OpenFileButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenFileButt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OpenFileButt.ForeColor = System.Drawing.Color.White;
            this.OpenFileButt.Location = new System.Drawing.Point(413, 457);
            this.OpenFileButt.Name = "OpenFileButt";
            this.OpenFileButt.Size = new System.Drawing.Size(194, 61);
            this.OpenFileButt.TabIndex = 5;
            this.OpenFileButt.Text = "OpenFile";
            this.OpenFileButt.UseVisualStyleBackColor = false;
            this.OpenFileButt.Click += new System.EventHandler(this.OpenFileButt_Click);
            // 
            // RefreshButt
            // 
            this.RefreshButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.RefreshButt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.RefreshButt.FlatAppearance.BorderSize = 3;
            this.RefreshButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RefreshButt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RefreshButt.ForeColor = System.Drawing.Color.White;
            this.RefreshButt.Location = new System.Drawing.Point(836, 458);
            this.RefreshButt.Name = "RefreshButt";
            this.RefreshButt.Size = new System.Drawing.Size(194, 61);
            this.RefreshButt.TabIndex = 6;
            this.RefreshButt.Text = "Refresh";
            this.RefreshButt.UseVisualStyleBackColor = false;
            this.RefreshButt.Click += new System.EventHandler(this.RefreshButt_Click);
            // 
            // InjectorChecker
            // 
            this.InjectorChecker.Tick += new System.EventHandler(this.InjectorChecker_Tick);
            // 
            // ClearButt
            // 
            this.ClearButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClearButt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClearButt.FlatAppearance.BorderSize = 3;
            this.ClearButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearButt.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClearButt.ForeColor = System.Drawing.Color.White;
            this.ClearButt.Location = new System.Drawing.Point(613, 457);
            this.ClearButt.Name = "ClearButt";
            this.ClearButt.Size = new System.Drawing.Size(194, 61);
            this.ClearButt.TabIndex = 7;
            this.ClearButt.Text = "Clear";
            this.ClearButt.UseVisualStyleBackColor = false;
            this.ClearButt.Click += new System.EventHandler(this.ClearButt_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1053, 531);
            this.Controls.Add(this.ClearButt);
            this.Controls.Add(this.RefreshButt);
            this.Controls.Add(this.OpenFileButt);
            this.Controls.Add(this.SaveFileButt);
            this.Controls.Add(this.ExecuteButt);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.fastColoredTextBox1);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label HeadText;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button CloseButt;
        private FastColoredTextBoxNS.FastColoredTextBox fastColoredTextBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button ExecuteButt;
        private System.Windows.Forms.Button SaveFileButt;
        private System.Windows.Forms.Button OpenFileButt;
        private System.Windows.Forms.Button RefreshButt;
        private System.Windows.Forms.Timer InjectorChecker;
        private System.Windows.Forms.Button ClearButt;
    }
}