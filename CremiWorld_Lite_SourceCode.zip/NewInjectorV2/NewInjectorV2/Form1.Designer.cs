﻿namespace NewInjectorV2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.HeadName = new System.Windows.Forms.Label();
            this.MinimazedButt = new System.Windows.Forms.Button();
            this.CloseButt = new System.Windows.Forms.Button();
            this.InjectButt = new System.Windows.Forms.Button();
            this.InjectorChecker = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.HeadName);
            this.panel1.Controls.Add(this.MinimazedButt);
            this.panel1.Controls.Add(this.CloseButt);
            this.panel1.Location = new System.Drawing.Point(-58, -18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(932, 84);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            // 
            // HeadName
            // 
            this.HeadName.AutoSize = true;
            this.HeadName.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HeadName.ForeColor = System.Drawing.Color.White;
            this.HeadName.Location = new System.Drawing.Point(337, 21);
            this.HeadName.Name = "HeadName";
            this.HeadName.Size = new System.Drawing.Size(255, 45);
            this.HeadName.TabIndex = 2;
            this.HeadName.Text = "CremiWorld Lite";
            this.HeadName.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeadName_MouseDown);
            this.HeadName.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeadName_MouseMove);
            // 
            // MinimazedButt
            // 
            this.MinimazedButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.MinimazedButt.FlatAppearance.BorderSize = 0;
            this.MinimazedButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinimazedButt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MinimazedButt.ForeColor = System.Drawing.Color.White;
            this.MinimazedButt.Location = new System.Drawing.Point(707, 21);
            this.MinimazedButt.Name = "MinimazedButt";
            this.MinimazedButt.Size = new System.Drawing.Size(85, 60);
            this.MinimazedButt.TabIndex = 1;
            this.MinimazedButt.Text = "_";
            this.MinimazedButt.UseVisualStyleBackColor = false;
            this.MinimazedButt.Click += new System.EventHandler(this.MinimazedButt_Click);
            // 
            // CloseButt
            // 
            this.CloseButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.CloseButt.FlatAppearance.BorderSize = 0;
            this.CloseButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButt.ForeColor = System.Drawing.Color.White;
            this.CloseButt.Location = new System.Drawing.Point(798, 21);
            this.CloseButt.Name = "CloseButt";
            this.CloseButt.Size = new System.Drawing.Size(85, 60);
            this.CloseButt.TabIndex = 0;
            this.CloseButt.Text = "X";
            this.CloseButt.UseVisualStyleBackColor = false;
            this.CloseButt.Click += new System.EventHandler(this.CloseButt_Click);
            // 
            // InjectButt
            // 
            this.InjectButt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.InjectButt.FlatAppearance.BorderSize = 0;
            this.InjectButt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InjectButt.Font = new System.Drawing.Font("Segoe UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InjectButt.ForeColor = System.Drawing.Color.White;
            this.InjectButt.Location = new System.Drawing.Point(283, 197);
            this.InjectButt.Name = "InjectButt";
            this.InjectButt.Size = new System.Drawing.Size(260, 76);
            this.InjectButt.TabIndex = 1;
            this.InjectButt.Text = "Inject";
            this.InjectButt.UseVisualStyleBackColor = false;
            this.InjectButt.Click += new System.EventHandler(this.InjectButt_Click);
            // 
            // InjectorChecker
            // 
            this.InjectorChecker.Tick += new System.EventHandler(this.InjectorChecker_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1, 368);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Creator: Cremi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(1, 406);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(305, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Telegram Developer: @Cremiii";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(827, 498);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InjectButt);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Injecting";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button MinimazedButt;
        private System.Windows.Forms.Button CloseButt;
        private System.Windows.Forms.Label HeadName;
        private System.Windows.Forms.Button InjectButt;
        private System.Windows.Forms.Timer InjectorChecker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

